// ============================================================
//  HOSPITAL PATIENT MANAGEMENT SYSTEM
//  Demonstrates: Java Swing + JDBC + Threading (SwingWorker)
//  Course: Object Oriented Programming (Java) — Semester II
//  Instructor: Mr. Muhammad Saleem
//  University: Dawood University of Engineering & Technology
// ============================================================

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.*;
import java.util.*;
import java.util.List;

// ============================================================
//  1. ABSTRACT BASE CLASS — Abstraction + Encapsulation
// ============================================================
abstract class Person {
    private String name;   // Encapsulation: private fields
    private int age;
    private String id;

    public Person(String id, String name, int age) {
        this.id   = id;
        this.name = name;
        this.age  = age;
    }

    // Getters and Setters (Encapsulation)
    public String getId()   { return id;   }
    public String getName() { return name; }
    public int    getAge()  { return age;  }
    public void   setName(String name) { this.name = name; }
    public void   setAge(int age)      { this.age  = age;  }

    // Abstract method — must be overridden (Abstraction)
    public abstract String getRole();

    // Polymorphism: overriding toString()
    @Override
    public String toString() {
        return "[" + getRole() + "] ID: " + id + " | Name: " + name + " | Age: " + age;
    }
}

// ============================================================
//  2. PATIENT CLASS — Inheritance
// ============================================================
class Patient extends Person {
    private String disease;
    private String doctorAssigned;
    private String status; // "Admitted" or "Discharged"

    public Patient(String id, String name, int age, String disease, String doctorAssigned) {
        super(id, name, age); // Call parent constructor
        this.disease        = disease;
        this.doctorAssigned = doctorAssigned;
        this.status         = "Admitted";
    }

    public String getDisease()        { return disease;        }
    public String getDoctorAssigned() { return doctorAssigned; }
    public String getStatus()         { return status;         }
    public void   setStatus(String s) { this.status = s;       }

    @Override
    public String getRole() { return "Patient"; } // Polymorphism
}

// ============================================================
//  3. DOCTOR CLASS — Inheritance
// ============================================================
class Doctor extends Person {
    private String specialization;

    public Doctor(String id, String name, int age, String specialization) {
        super(id, name, age);
        this.specialization = specialization;
    }

    public String getSpecialization() { return specialization; }

    @Override
    public String getRole() { return "Doctor"; } // Polymorphism
}

// ============================================================
//  4. DATABASE HELPER — JDBC
//  NOTE: Uses SQLite (no MySQL server needed for testing).
//        For real deployment, change URL/driver to MySQL.
// ============================================================
class DBConnection {
    // --- CHANGE THESE FOR MYSQL ---
    // private static final String URL  = "jdbc:mysql://localhost:3306/hospital_db";
    // private static final String USER = "root";
    // private static final String PASS = "your_password";

    // SQLite (for testing without a server)
    private static final String URL = "jdbc:sqlite:hospital.db";

    private static Connection conn = null;

    public static Connection getConnection() throws SQLException {
        if (conn == null || conn.isClosed()) {
            conn = DriverManager.getConnection(URL);
        }
        return conn;
    }

    public static void initDatabase() {
        String sql = "CREATE TABLE IF NOT EXISTS patients ("
                   + "id TEXT PRIMARY KEY,"
                   + "name TEXT NOT NULL,"
                   + "age INTEGER,"
                   + "disease TEXT,"
                   + "doctor TEXT,"
                   + "status TEXT DEFAULT 'Admitted'"
                   + ")";
        try (Statement stmt = getConnection().createStatement()) {
            stmt.execute(sql);
            System.out.println("[DB] Database initialized successfully.");
        } catch (SQLException e) {
            System.out.println("[DB] Error: " + e.getMessage());
        }
    }
}

// ============================================================
//  5. DATA ACCESS OBJECT — JDBC CRUD Operations
// ============================================================
class PatientDAO {

    // INSERT a new patient
    public static boolean addPatient(Patient p) {
        String sql = "INSERT INTO patients (id, name, age, adisease, doctor, status) VALUES (?,?,?,?,?,?)";
        try (PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, p.getId());
            ps.setString(2, p.getName());
            ps.setInt   (3, p.getAge());
            ps.setString(4, p.getDisease());
            ps.setString(5, p.getDoctorAssigned());
            ps.setString(6, p.getStatus());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("[DAO] Add error: " + e.getMessage());
            return false;
        }
    }

    // SELECT all patients
    public static List<Patient> getAllPatients() {
        List<Patient> list = new ArrayList<>();
        String sql = "SELECT * FROM patients";
        try (Statement stmt = DBConnection.getConnection().createStatement();
             ResultSet rs   = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Patient p = new Patient(
                    rs.getString("id"),
                    rs.getString("name"),
                    rs.getInt   ("age"),
                    rs.getString("disease"),
                    rs.getString("doctor")
                );
                p.setStatus(rs.getString("status"));
                list.add(p);
            }
        } catch (SQLException e) {
            System.out.println("[DAO] Fetch error: " + e.getMessage());
        }
        return list;
    }

    // UPDATE patient status to Discharged
    public static boolean dischargePatient(String id) {
        String sql = "UPDATE patients SET status = 'Discharged' WHERE id = ?";
        try (PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, id);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("[DAO] Discharge error: " + e.getMessage());
            return false;
        }
    }

    // SELECT patients by name (search)
    public static List<Patient> searchByName(String name) {
        List<Patient> list = new ArrayList<>();
        String sql = "SELECT * FROM patients WHERE name LIKE ?";
        try (PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, "%" + name + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Patient p = new Patient(
                    rs.getString("id"),
                    rs.getString("name"),
                    rs.getInt   ("age"),
                    rs.getString("disease"),
                    rs.getString("doctor")
                );
                p.setStatus(rs.getString("status"));
                list.add(p);
            }
        } catch (SQLException e) {
            System.out.println("[DAO] Search error: " + e.getMessage());
        }
        return list;
    }
}

// ============================================================
//  6. THREADING — SwingWorker for background DB loading
//  Prevents UI freeze while fetching data from database
// ============================================================
class PatientLoader extends SwingWorker<List<Patient>, Void> {
    private final DefaultTableModel tableModel;
    private final JLabel            statusLabel;

    public PatientLoader(DefaultTableModel tableModel, JLabel statusLabel) {
        this.tableModel  = tableModel;
        this.statusLabel = statusLabel;
    }

    @Override
    protected List<Patient> doInBackground() throws Exception {
        // Runs on BACKGROUND thread — safe to do heavy DB work here
        statusLabel.setText("⏳ Loading patients from database...");
        Thread.sleep(800); // Simulate network/DB delay
        return PatientDAO.getAllPatients();
    }

    @Override
    protected void done() {
        // Runs on EVENT DISPATCH THREAD — safe to update Swing UI here
        try {
            List<Patient> patients = get();
            tableModel.setRowCount(0); // Clear existing rows
            for (Patient p : patients) {
                tableModel.addRow(new Object[]{
                    p.getId(), p.getName(), p.getAge(),
                    p.getDisease(), p.getDoctorAssigned(), p.getStatus()
                });
            }
            statusLabel.setText("✅ Loaded " + patients.size() + " patient(s) successfully.");
        } catch (Exception e) {
            statusLabel.setText("❌ Error loading patients: " + e.getMessage());
        }
    }
}

// ============================================================
//  7. LOGIN FRAME — Swing GUI
// ============================================================
class LoginFrame extends JFrame {
    private JTextField     usernameField;
    private JPasswordField passwordField;

    public LoginFrame() {
        setTitle("Hospital Management System — Login");
        setSize(420, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // Main panel
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(30, 56, 100));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill   = GridBagConstraints.HORIZONTAL;

        // Title
        JLabel title = new JLabel("🏥 Hospital Login", JLabel.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(title, gbc);

        // Username
        gbc.gridwidth = 1; gbc.gridy = 1; gbc.gridx = 0;
        JLabel uLabel = new JLabel("Username:");
        uLabel.setForeground(Color.WHITE);
        panel.add(uLabel, gbc);

        gbc.gridx = 1;
        usernameField = new JTextField("admin", 15);
        panel.add(usernameField, gbc);

        // Password
        gbc.gridy = 2; gbc.gridx = 0;
        JLabel pLabel = new JLabel("Password:");
        pLabel.setForeground(Color.WHITE);
        panel.add(pLabel, gbc);

        gbc.gridx = 1;
        passwordField = new JPasswordField("1234", 15);
        panel.add(passwordField, gbc);

        // Login button
        gbc.gridy = 3; gbc.gridx = 0; gbc.gridwidth = 2;
        JButton loginBtn = new JButton("Login");
        loginBtn.setBackground(new Color(192, 57, 43));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFont(new Font("SansSerif", Font.BOLD, 14));
        loginBtn.addActionListener(e -> handleLogin());
        panel.add(loginBtn, gbc);

        add(panel);
        setVisible(true);
    }

    private void handleLogin() {
        String user = usernameField.getText();
        String pass = new String(passwordField.getPassword());
        if (user.equals("admin") && pass.equals("1234")) {
            dispose(); // Close login window
            new DashboardFrame(); // Open main dashboard
        } else {
            JOptionPane.showMessageDialog(this,
                "Invalid credentials!\nUse: admin / 1234",
                "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
    }
}

// ============================================================
//  8. DASHBOARD FRAME — Main Swing GUI with all features
// ============================================================
class DashboardFrame extends JFrame {
    private DefaultTableModel tableModel;
    private JTable            patientTable;
    private JLabel            statusLabel;

    // Input fields
    private JTextField idField, nameField, ageField, diseaseField, doctorField, searchField;

    public DashboardFrame() {
        setTitle("🏥 Hospital Patient Management System");
        setSize(950, 680);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // ── TOP HEADER ──
        JPanel header = new JPanel();
        header.setBackground(new Color(30, 56, 100));
        header.setBorder(new EmptyBorder(12, 20, 12, 20));
        JLabel headerLabel = new JLabel("🏥 Hospital Patient Management System");
        headerLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        headerLabel.setForeground(Color.WHITE);
        header.add(headerLabel);
        add(header, BorderLayout.NORTH);

        // ── LEFT PANEL: Add Patient Form ──
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(30, 56, 100), 2),
            "Add New Patient", TitledBorder.LEFT, TitledBorder.TOP,
            new Font("SansSerif", Font.BOLD, 13), new Color(30, 56, 100)));
        formPanel.setPreferredSize(new Dimension(260, 0));
        formPanel.setBackground(new Color(245, 248, 255));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 8, 6, 8);
        gbc.fill   = GridBagConstraints.HORIZONTAL;
        gbc.gridx  = 0;

        String[] labels = {"Patient ID:", "Full Name:", "Age:", "Disease:", "Doctor Assigned:"};
        idField      = new JTextField(); nameField   = new JTextField();
        ageField     = new JTextField(); diseaseField = new JTextField();
        doctorField  = new JTextField();
        JTextField[] fields = {idField, nameField, ageField, diseaseField, doctorField};

        for (int i = 0; i < labels.length; i++) {
            gbc.gridy = i * 2;
            JLabel lbl = new JLabel(labels[i]);
            lbl.setFont(new Font("SansSerif", Font.BOLD, 12));
            formPanel.add(lbl, gbc);
            gbc.gridy = i * 2 + 1;
            fields[i].setFont(new Font("SansSerif", Font.PLAIN, 13));
            formPanel.add(fields[i], gbc);
        }

        // Add Patient Button
        gbc.gridy = 10;
        JButton addBtn = new JButton("➕ Add Patient");
        addBtn.setBackground(Color.BLACK);
        addBtn.setForeground(Color.GRAY);
        addBtn.setFont(new Font("SansSerif", Font.BOLD, 13));
        addBtn.addActionListener(e -> addPatient());
        formPanel.add(addBtn, gbc);

        // Discharge Button
        gbc.gridy = 11;
        JButton dischargeBtn = new JButton("🚪 Discharge Selected");
        dischargeBtn.setBackground(Color.BLACK);
        dischargeBtn.setForeground(Color.orange);
        dischargeBtn.setFont(new Font("SansSerif", Font.BOLD, 13));
        dischargeBtn.addActionListener(e -> dischargePatient());
        formPanel.add(dischargeBtn, gbc);

        add(formPanel, BorderLayout.WEST);

        // ── CENTER: Patient Table ──
        String[] columns = {"ID", "Name", "Age", "Disease", "Doctor", "Status"};
        tableModel   = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        patientTable = new JTable(tableModel);
        patientTable.setFont(new Font("SansSerif", Font.PLAIN, 13));
        patientTable.setRowHeight(26);
        patientTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 13));
        patientTable.getTableHeader().setBackground(Color.BLUE);
        patientTable.getTableHeader().setForeground(Color.GREEN);
        patientTable.setSelectionBackground(new Color(174, 214, 241));

        // Color rows based on status
        patientTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object val,
                    boolean sel, boolean foc, int row, int col) {
                Component c = super.getTableCellRendererComponent(t, val, sel, foc, row, col);
                String status = (String) t.getModel().getValueAt(row, 5);
                if (!sel) {
                    c.setBackground("Discharged".equals(status)
                        ? new Color(250, 219, 216)
                        : new Color(234, 250, 241));
                }
                return c;
            }
        });

        JScrollPane scrollPane = new JScrollPane(patientTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(30, 56, 100), 2),
            "Patient Records", TitledBorder.LEFT, TitledBorder.TOP,
            new Font("SansSerif", Font.BOLD, 13), new Color(30, 56, 100)));
        add(scrollPane, BorderLayout.CENTER);

        // ── BOTTOM: Search + Status ──
        JPanel bottomPanel = new JPanel(new BorderLayout(10, 5));
        bottomPanel.setBorder(new EmptyBorder(5, 10, 10, 10));
        bottomPanel.setBackground(Color.BLACK);

        // Search bar
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBackground(Color.PINK);
        searchPanel.add(new JLabel("🔍 Search by Name:"));
        searchField = new JTextField(20);
        searchPanel.add(searchField);
        JButton searchBtn = new JButton("Search");
        searchBtn.setBackground(new Color(52, 152, 219));
        searchBtn.setForeground(Color.WHITE);
        searchBtn.addActionListener(e -> searchPatient());
        searchPanel.add(searchBtn);

        JButton refreshBtn = new JButton("🔄 Refresh All");
        refreshBtn.addActionListener(e -> loadPatientsWithThread());
        searchPanel.add(refreshBtn);

        bottomPanel.add(searchPanel, BorderLayout.NORTH);

        statusLabel = new JLabel("✅ System Ready.");
        statusLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
        statusLabel.setForeground(Color.WHITE);
        statusLabel.setBackground(Color.PINK);
        bottomPanel.add(statusLabel, BorderLayout.SOUTH);

        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);

        // Auto-load patients on startup using Threading
        loadPatientsWithThread();
    }

    // Helper to set padding on JPanel
    private void setPaddingHelper() {}

    // ── Add Patient (JDBC INSERT) ──
    private void addPatient() {
        try {
            String id      = idField.getText().trim();
            String name    = nameField.getText().trim();
            int    age     = Integer.parseInt(ageField.getText().trim());
            String disease = diseaseField.getText().trim();
            String doctor  = doctorField.getText().trim();

            if (id.isEmpty() || name.isEmpty() || disease.isEmpty() || doctor.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields!", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Patient p = new Patient(id, name, age, disease, doctor);
            if (PatientDAO.addPatient(p)) {
                statusLabel.setText("✅ Patient '" + name + "' added successfully.");
                clearForm();
                loadPatientsWithThread(); // Reload table via thread
            } else {
                JOptionPane.showMessageDialog(this, "Error adding patient! ID may already exist.", "DB Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Age must be a valid number!", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ── Discharge Patient (JDBC UPDATE) ──
    private void dischargePatient() {
        int selectedRow = patientTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a patient to discharge.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String id   = (String) tableModel.getValueAt(selectedRow, 0);
        String name = (String) tableModel.getValueAt(selectedRow, 1);

        int confirm = JOptionPane.showConfirmDialog(this,
            "Discharge patient: " + name + " (ID: " + id + ")?",
            "Confirm Discharge", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            PatientDAO.dischargePatient(id);
            statusLabel.setText("🚪 Patient '" + name + "' discharged.");
            loadPatientsWithThread();
        }
    }

    // ── Search Patient (JDBC SELECT LIKE) ──
    private void searchPatient() {
        String query = searchField.getText().trim();
        if (query.isEmpty()) { loadPatientsWithThread(); return; }

        List<Patient> results = PatientDAO.searchByName(query);
        tableModel.setRowCount(0);
        for (Patient p : results) {
            tableModel.addRow(new Object[]{
                p.getId(), p.getName(), p.getAge(),
                p.getDisease(), p.getDoctorAssigned(), p.getStatus()
            });
        }
        statusLabel.setText("🔍 Found " + results.size() + " result(s) for: '" + query + "'");
    }

    // ── Load with Threading (SwingWorker) ──
    private void loadPatientsWithThread() {
        // SwingWorker runs DB call on background thread → updates UI on EDT
        new PatientLoader(tableModel, statusLabel).execute();
    }

    private void clearForm() {
        idField.setText(""); nameField.setText(""); ageField.setText("");
        diseaseField.setText(""); doctorField.setText("");
    }
}


public class HospitalManagementSystem {
    public static void main(String[] args) {
        // Initialize database and create tables
        DBConnection.initDatabase();

        // Launch Swing UI on the Event Dispatch Thread (EDT) — Threading best practice
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new LoginFrame();
        });
    }
}
